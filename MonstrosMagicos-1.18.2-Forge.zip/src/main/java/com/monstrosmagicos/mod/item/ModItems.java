package com.monstrosmagicos.mod.item;

import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.ModEntities;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MonstrosMagicosMod.MOD_ID);

    public static final RegistryObject<Item> VARINHA_MAGICO = ITEMS.register("varinha_magico",
            () -> new VarinhaMagicoItem(new Item.Properties()
                    .tab(CreativeModeTab.TAB_COMBAT)
                    .stacksTo(1)
                    .durability(250)
                    .rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> MONSTRO_LUZ_SPAWN_EGG = ITEMS.register("monstro_luz_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MONSTRO_LUZ, 0xFFF39C, 0xD4AC0D,
                    new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

    public static final RegistryObject<Item> MONSTRO_GELEIA_SPAWN_EGG = ITEMS.register("monstro_geleia_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MONSTRO_GELEIA, 0x2ECC71, 0x1E8449,
                    new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

    public static final RegistryObject<Item> MAGICO_SPAWN_EGG = ITEMS.register("magico_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MAGICO, 0x6C3483, 0xF1C40F,
                    new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
