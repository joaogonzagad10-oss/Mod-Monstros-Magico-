package com.monstrosmagicos.mod;

import com.monstrosmagicos.mod.entity.ModEntities;
import com.monstrosmagicos.mod.item.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(MonstrosMagicosMod.MOD_ID)
public class MonstrosMagicosMod {
    public static final String MOD_ID = "monstrosmagicos";
    public static final Logger LOGGER = LogManager.getLogger();

    public MonstrosMagicosMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.register(modEventBus);
        ModEntities.register(modEventBus);

        MinecraftForge.EVENT_BUS.register(this);
    }
}
