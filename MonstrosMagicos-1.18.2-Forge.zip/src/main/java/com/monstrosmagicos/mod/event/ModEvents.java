package com.monstrosmagicos.mod.event;

import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.ModEntities;
import com.monstrosmagicos.mod.entity.custom.MagicoEntity;
import com.monstrosmagicos.mod.entity.custom.MonstroGeleiaEntity;
import com.monstrosmagicos.mod.entity.custom.MonstroLuzEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

import java.util.List;

public class ModEvents {

    @Mod.EventBusSubscriber(modid = MonstrosMagicosMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBusEvents {
        @SubscribeEvent
        public static void entityAttributeEvent(EntityAttributeCreationEvent event) {
            event.put(ModEntities.MONSTRO_LUZ.get(), MonstroLuzEntity.createAttributes().build());
            event.put(ModEntities.MONSTRO_GELEIA.get(), MonstroGeleiaEntity.createAttributes().build());
            event.put(ModEntities.MAGICO.get(), MagicoEntity.createAttributes().build());
        }

        @SubscribeEvent
        public static void commonSetup(FMLCommonSetupEvent event) {
            event.enqueueWork(() -> {
                SpawnPlacements.register(ModEntities.MONSTRO_GELEIA.get(),
                        SpawnPlacements.Type.ON_GROUND,
                        Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        Monster::checkMonsterSpawnRules);
            });
        }
    }

    @Mod.EventBusSubscriber(modid = MonstrosMagicosMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBusEvents {
        @SubscribeEvent
        public static void onWorldTick(TickEvent.WorldTickEvent event) {
            if (event.phase != TickEvent.Phase.END || event.world.isClientSide) return;
            if (!(event.world instanceof ServerLevel serverLevel)) return;

            // 1. Spawn do Monstro de Luz perto de casas com luz que NÃO seja tocha (a cada 15 segundos)
            if (serverLevel.getGameTime() % 300 == 0) {
                for (ServerPlayer player : serverLevel.players()) {
                    if (player.isCreative() || player.isSpectator()) continue;

                    List<MonstroLuzEntity> nearby = serverLevel.getEntitiesOfClass(
                            MonstroLuzEntity.class, new AABB(player.blockPosition()).inflate(32.0D));
                    if (!nearby.isEmpty()) continue;

                    BlockPos pPos = player.blockPosition();
                    boolean foundNonTorchLight = false;
                    BlockPos lightLocation = null;

                    for (BlockPos check : BlockPos.betweenClosed(pPos.offset(-14, -4, -14), pPos.offset(14, 6, 14))) {
                        if (MonstroLuzEntity.isNonTorchLight(serverLevel.getBlockState(check))) {
                            foundNonTorchLight = true;
                            lightLocation = check.immutable();
                            break;
                        }
                    }

                    if (foundNonTorchLight && lightLocation != null && serverLevel.random.nextFloat() < 0.45F) {
                        for (int attempt = 0; attempt < 10; attempt++) {
                            int sx = lightLocation.getX() + serverLevel.random.nextInt(13) - 6;
                            int sz = lightLocation.getZ() + serverLevel.random.nextInt(13) - 6;
                            int sy = lightLocation.getY();
                            BlockPos spawnPos = new BlockPos(sx, sy, sz);

                            if (serverLevel.getBlockState(spawnPos).isAir()
                                    && serverLevel.getBlockState(spawnPos.above()).isAir()
                                    && serverLevel.getBlockState(spawnPos.below()).getMaterial().isSolid()) {
                                MonstroLuzEntity monstroLuz = ModEntities.MONSTRO_LUZ.get().create(serverLevel);
                                if (monstroLuz != null) {
                                    monstroLuz.moveTo(sx + 0.5, sy, sz + 0.5, serverLevel.random.nextFloat() * 360F, 0F);
                                    monstroLuz.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(spawnPos),
                                            MobSpawnType.NATURAL, null, null);
                                    serverLevel.addFreshEntity(monstroLuz);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            // 2. Spawn do Mágico em Woodland Mansion ou Pillager Outpost (a cada 20 segundos)
            if (serverLevel.getGameTime() % 400 == 0) {
                for (ServerPlayer player : serverLevel.players()) {
                    BlockPos pos = player.blockPosition();
                    boolean inOutpost = serverLevel.structureFeatureManager()
                            .getStructureAt(pos, StructureFeature.PILLAGER_OUTPOST).isValid();
                    boolean inMansion = serverLevel.structureFeatureManager()
                            .getStructureAt(pos, StructureFeature.WOODLAND_MANSION).isValid();

                    if (inOutpost || inMansion) {
                        List<MagicoEntity> existing = serverLevel.getEntitiesOfClass(
                                MagicoEntity.class, new AABB(pos).inflate(64.0D));
                        if (existing.isEmpty()) {
                            BlockPos spawnPos = pos.offset(6, 0, 6);
                            int groundY = serverLevel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                                    spawnPos.getX(), spawnPos.getZ());
                            BlockPos finalPos = new BlockPos(spawnPos.getX(), groundY, spawnPos.getZ());

                            MagicoEntity magico = ModEntities.MAGICO.get().create(serverLevel);
                            if (magico != null) {
                                magico.moveTo(finalPos.getX() + 0.5, finalPos.getY(), finalPos.getZ() + 0.5, 0F, 0F);
                                magico.finalizeSpawn(serverLevel, serverLevel.getCurrentDifficultyAt(finalPos),
                                        MobSpawnType.STRUCTURE, null, null);
                                serverLevel.addFreshEntity(magico);
                            }
                        }
                    }
                }
            }
        }
    }
}
