package com.monstrosmagicos.mod.entity.custom;

import com.monstrosmagicos.mod.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.*;

public class MagicoEntity extends Monster {
    private static final EntityDataAccessor<Integer> ROUND =
            SynchedEntityData.defineId(MagicoEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> GIANT_MODE =
            SynchedEntityData.defineId(MagicoEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> STUNNED =
            SynchedEntityData.defineId(MagicoEntity.class, EntityDataSerializers.BOOLEAN);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            new TextComponent("§5§lO Mágico Supremo"),
            BossEvent.BossBarColor.PURPLE,
            BossEvent.BossBarOverlay.NOTCHED_10);

    // Controle dos Rounds
    private boolean fightStarted = false;
    private final List<UUID> summonedMobs = new ArrayList<>();

    // Round 2: 2 minutos = 2400 ticks
    private int round2Timer = 0;
    private static final int ROUND2_DURATION = 2400;

    // Round 3: Animação suprema, arena 15x15, lava, mão gigante e 3 ciclos de tontura
    private int round3CutsceneTicks = 0;
    private int round3SubPhase = 0; // 0 = cutscene, 1 = vingadores, 2 = lava + mão gigante, 3 = tonto
    private int phaseTimer = 0;
    private int stunCyclesCompleted = 0;
    private final List<BlockPos> temporaryLavaPos = new ArrayList<>();
    private BlockPos giantHandTarget = null;
    private int giantHandCountdown = 0;
    private BlockPos arenaCenter = null;

    public MagicoEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 150;
        this.setPersistenceRequired();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ROUND, 1);
        this.entityData.define(GIANT_MODE, false);
        this.entityData.define(STUNNED, false);
    }

    public int getRound() {
        return this.entityData.get(ROUND);
    }

    public void setRound(int round) {
        this.entityData.set(ROUND, round);
    }

    public boolean isGiantMode() {
        return this.entityData.get(GIANT_MODE);
    }

    public void setGiantMode(boolean giant) {
        this.entityData.set(GIANT_MODE, giant);
        this.refreshDimensions();
    }

    public boolean isStunned() {
        return this.entityData.get(STUNNED);
    }

    public void setStunned(boolean stunned) {
        this.entityData.set(STUNNED, stunned);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        if (this.isGiantMode()) {
            return EntityDimensions.scalable(1.8F, 4.8F);
        }
        return super.getDimensions(pose);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D) // 100 HP por vida/round
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ARMOR, 6.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new AvoidEntityGoal<>(this, Player.class, 6.0F, 1.0D, 1.2D) {
            @Override
            public boolean canUse() {
                return !isStunned() && super.canUse();
            }
        });
        this.goalSelector.addGoal(2, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(3, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData spawnData,
                                        @Nullable net.minecraft.nbt.CompoundTag tag) {
        this.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.VARINHA_MAGICO.get()));
        return super.finalizeSpawn(level, difficulty, reason, spawnData, tag);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level.isClientSide || !(this.level instanceof ServerLevel serverLevel)) return;

        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        Player target = this.level.getNearestPlayer(this, 36.0D);
        if (target == null || target.isCreative() || target.isSpectator()) {
            // Se o jogador morrer durante o Round 2, reinicia o timer de 2 minutos
            if (getRound() == 2 && round2Timer > 0) {
                round2Timer = 0;
            }
            return;
        }

        if (!fightStarted) {
            fightStarted = true;
            startRound1(serverLevel, target);
        }

        int currentRound = getRound();
        if (currentRound == 1) {
            tickRound1(serverLevel, target);
        } else if (currentRound == 2) {
            tickRound2(serverLevel, target);
        } else if (currentRound == 3) {
            tickRound3(serverLevel, target);
        }
    }

    // ==================== ROUND 1: INVOCA MOBS ALEATÓRIOS ====================
    private void startRound1(ServerLevel level, Player player) {
        setRound(1);
        this.setHealth(300.0F);
        this.bossEvent.setName(new TextComponent("§5§lO Mágico - Round 1: Invocação"));
        broadcastMessage(level, "§5[Mágico] §fVamos ver se você sobrevive aos meus servos! (Round 1/3)");
        spawnRandomWave(level);
    }

    private void spawnRandomWave(ServerLevel level) {
        summonedMobs.clear();
        int choice = this.random.nextInt(3);
        level.playSound(null, this.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, SoundSource.HOSTILE, 1.5F, 1.0F);
        level.sendParticles(ParticleTypes.WITCH, this.getX(), this.getY() + 1.5D, this.getZ(), 40, 1.0, 1.0, 1.0, 0.1);

        if (choice == 0) {
            // 3 Zumbis
            for (int i = 0; i < 3; i++) {
                Zombie z = EntityType.ZOMBIE.create(level);
                if (z != null) {
                    z.moveTo(this.getX() + (i - 1) * 2.0, this.getY(), this.getZ() + 2.0);
                    level.addFreshEntity(z);
                    summonedMobs.add(z.getUUID());
                }
            }
        } else if (choice == 1) {
            // 1 Slime Grande
            Slime s = EntityType.SLIME.create(level);
            if (s != null) {
                s.setSize(3, true);
                s.moveTo(this.getX(), this.getY(), this.getZ() + 2.5);
                level.addFreshEntity(s);
                summonedMobs.add(s.getUUID());
            }
        } else {
            // 5 Esqueletos
            for (int i = 0; i < 5; i++) {
                Skeleton sk = EntityType.SKELETON.create(level);
                if (sk != null) {
                    sk.moveTo(this.getX() + (i - 2) * 1.5, this.getY(), this.getZ() + 2.0);
                    sk.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(net.minecraft.world.item.Items.BOW));
                    level.addFreshEntity(sk);
                    summonedMobs.add(sk.getUUID());
                }
            }
        }
    }

    private void tickRound1(ServerLevel level, Player player) {
        if (this.tickCount % 15 != 0) return;

        // Verifica se todos os mobs invocados foram derrotados
        summonedMobs.removeIf(uuid -> {
            Entity e = level.getEntity(uuid);
            return e == null || !e.isAlive();
        });

        if (summonedMobs.isEmpty()) {
            // Perde 1 vida (100 HP) e vai para o Round 2!
            this.setHealth(200.0F);
            level.playSound(null, this.blockPosition(), SoundEvents.TOTEM_USE, SoundSource.HOSTILE, 1.2F, 0.8F);
            level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0, this.getZ(), 1, 0, 0, 0, 0);
            startRound2(level);
        }
    }

    // ==================== ROUND 2: BIGORNAS E AREIAS DO CÉU POR 2 MINUTOS ====================
    private void startRound2(ServerLevel level) {
        setRound(2);
        round2Timer = 0;
        this.bossEvent.setName(new TextComponent("§6§lO Mágico - Round 2: Chuva do Céu (2:00)"));
        broadcastMessage(level, "§5[Mágico] §cVocê derrotou meus servos?! Aguente 2 minutos de chuva mortal! (Round 2/3)");
    }

    private void tickRound2(ServerLevel level, Player player) {
        if (!player.isAlive()) {
            round2Timer = 0;
            return;
        }

        round2Timer++;
        int remainingSec = Math.max(0, (ROUND2_DURATION - round2Timer) / 20);
        this.bossEvent.setName(new TextComponent("§6§lO Mágico - Round 2: Sobreviva (" + remainingSec + "s)"));

        // Faz cair bigornas e areia ao redor e em cima da área do jogador
        if (round2Timer % 14 == 0) {
            for (int i = 0; i < 3; i++) {
                int offsetX = (i == 0) ? 0 : this.random.nextInt(11) - 5;
                int offsetZ = (i == 0) ? 0 : this.random.nextInt(11) - 5;
                BlockPos dropPos = player.blockPosition().offset(offsetX, 14, offsetZ);

                BlockState fallingState = this.random.nextBoolean()
                        ? Blocks.ANVIL.defaultBlockState()
                        : Blocks.SAND.defaultBlockState();

                FallingBlockEntity falling = FallingBlockEntity.fall(level, dropPos, fallingState);
                falling.setHurtsEntities(2.0F, 40);
                falling.dropItem = false;
            }
            level.playSound(null, player.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.HOSTILE, 0.4F, 1.5F);
        }

        if (round2Timer >= ROUND2_DURATION) {
            // Sobreviveu 2 minutos sem morrer! Perde a 2ª vida e entra no Round 3!
            this.setHealth(100.0F);
            startRound3(level, player);
        }
    }

    // ==================== ROUND 3: ARENA 15x15, GIGANTE, VINGADORES, LAVA E MÃO GIGANTE ====================
    private void startRound3(ServerLevel level, Player player) {
        setRound(3);
        round3SubPhase = 0;
        round3CutsceneTicks = 0;
        stunCyclesCompleted = 0;
        arenaCenter = player.blockPosition();
        this.bossEvent.setName(new TextComponent("§4§lO Mágico Supremo - Round Final!"));
        broadcastMessage(level, "§4[Mágico Supremo] §lCHEGA! CONTEMPLE MINHA FORMA SUPREMA! (Round 3/3)");
        level.playSound(null, arenaCenter, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.5F, 0.7F);
    }

    private void tickRound3(ServerLevel level, Player player) {
        // Subfase 0: Animação Suprema - Apaga blocos criando plataforma 15x15 e fica Gigante
        if (round3SubPhase == 0) {
            round3CutsceneTicks++;
            this.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 10, 1, false, false));
            level.sendParticles(ParticleTypes.DRAGON_BREATH,
                    this.getX(), this.getY() + 1.5D, this.getZ(),
                    30, 2.0, 2.0, 2.0, 0.05);

            // Tick 30: Corta e apaga os blocos em volta deixando apenas uma plataforma 15x15
            if (round3CutsceneTicks == 30 && arenaCenter != null) {
                carvePlatform15x15(level, arenaCenter);
                player.teleportTo(arenaCenter.getX() + 0.5, arenaCenter.getY() + 1.0, arenaCenter.getZ() + 4.5);
                this.teleportTo(arenaCenter.getX() + 0.5, arenaCenter.getY() + 1.0, arenaCenter.getZ() - 4.5);
                level.playSound(null, arenaCenter, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5F, 0.8F);
            }

            // Tick 70: Animação ficando Gigante e invocando Vingadores
            if (round3CutsceneTicks == 70) {
                setGiantMode(true);
                level.playSound(null, this.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 1.5F, 0.6F);
                level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING,
                        this.getX(), this.getY() + 2.5D, this.getZ(),
                        80, 1.5, 2.5, 1.5, 0.2);

                spawnVindicators(level);
                round3SubPhase = 1;
                phaseTimer = 0;
            }
            return;
        }

        // Subfase 1: Derrotar os Vingadores invocados
        if (round3SubPhase == 1) {
            if (this.tickCount % 15 == 0) {
                summonedMobs.removeIf(uuid -> {
                    Entity e = level.getEntity(uuid);
                    return e == null || !e.isAlive();
                });
                if (summonedMobs.isEmpty()) {
                    round3SubPhase = 2;
                    phaseTimer = 0;
                    spawnTemporaryLava(level);
                    broadcastMessage(level, "§4[Mágico Gigante] §cO chão vai queimar! Desvie da lava e da minha mão!");
                }
            }
            return;
        }

        // Subfase 2: Lava abrindo no chão + Ataque de Mão Gigante com aviso no chão
        if (round3SubPhase == 2) {
            phaseTimer++;

            // Alerta da Mão Gigante no chão
            if (phaseTimer == 60) {
                giantHandTarget = player.blockPosition();
                giantHandCountdown = 35; // ~1.75s para desviar
                level.playSound(null, giantHandTarget, SoundEvents.BELL_BLOCK, SoundSource.HOSTILE, 2.0F, 0.5F);
                player.displayClientMessage(new TextComponent("§c§l⚠ DESVIE! A MÃO GIGANTE VAI BATER ONDE VOCÊ ESTÁ!"), true);
            }

            if (giantHandTarget != null && giantHandCountdown > 0) {
                giantHandCountdown--;
                // Partículas vermelhas/fogo marcando o chão onde a mão vai cair
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        level.sendParticles(ParticleTypes.FLAME,
                                giantHandTarget.getX() + dx + 0.5,
                                giantHandTarget.getY() + 0.2,
                                giantHandTarget.getZ() + dz + 0.5,
                                2, 0.1, 0.05, 0.1, 0.01);
                    }
                }

                if (giantHandCountdown == 0) {
                    // Impacto da Mão Gigante!
                    level.playSound(null, giantHandTarget, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 1.5F, 0.6F);
                    level.sendParticles(ParticleTypes.EXPLOSION_EMITTER,
                            giantHandTarget.getX() + 0.5, giantHandTarget.getY() + 1.0, giantHandTarget.getZ() + 0.5,
                            2, 0.5, 0.5, 0.5, 0.0);

                    AABB impactBox = new AABB(giantHandTarget).inflate(2.5D, 2.0D, 2.5D);
                    for (Player p : level.getEntitiesOfClass(Player.class, impactBox)) {
                        p.hurt(DamageSource.mobAttack(this), 14.0F);
                        p.setDeltaMovement(0, 0.8D, 0);
                        p.hurtMarked = true;
                    }
                    giantHandTarget = null;
                }
            }

            // Após 140 ticks (7s), a lava some e o Mágico fica TONTO (vulnerável)!
            if (phaseTimer >= 140) {
                clearTemporaryLava(level);
                round3SubPhase = 3;
                phaseTimer = 0;
                setStunned(true);
                broadcastMessage(level, "§e§l⚡ O Mágico Gigante ficou TONTO! Ataque ele agora!");
                level.playSound(null, this.blockPosition(), SoundEvents.ANVIL_BREAK, SoundSource.HOSTILE, 1.2F, 0.7F);
            }
            return;
        }

        // Subfase 3: Mágico Tonto (janela de ataque para o jogador bater nele)
        if (round3SubPhase == 3) {
            phaseTimer++;
            if (phaseTimer % 10 == 0) {
                level.sendParticles(ParticleTypes.CRIT,
                        this.getX(), this.getY() + 4.5D, this.getZ(),
                        12, 0.8, 0.3, 0.8, 0.1);
            }

            // Se passou o tempo de tontura sem morrer, reinicia o ciclo de lava + mão gigante
            if (phaseTimer >= 100) {
                setStunned(false);
                round3SubPhase = 2;
                phaseTimer = 0;
                spawnTemporaryLava(level);
            }
        }
    }

    private void carvePlatform15x15(ServerLevel level, BlockPos center) {
        // Plataforma 15x15 (raio 7) e vazio ao redor num raio de 18 blocos
        for (int dx = -18; dx <= 18; dx++) {
            for (int dz = -18; dz <= 18; dz++) {
                boolean insidePlatform = Math.abs(dx) <= 7 && Math.abs(dz) <= 7;
                for (int dy = -3; dy <= 10; dy++) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    if (insidePlatform && dy == 0) {
                        level.setBlock(pos, Blocks.DEEPSLATE_TILES.defaultBlockState(), 3);
                    } else if (insidePlatform && dy < 0) {
                        level.setBlock(pos, Blocks.OBSIDIAN.defaultBlockState(), 3);
                    } else {
                        if (!level.getBlockState(pos).isAir()) {
                            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            }
        }
    }

    private void spawnVindicators(ServerLevel level) {
        summonedMobs.clear();
        for (int i = 0; i < 3; i++) {
            Vindicator v = EntityType.VINDICATOR.create(level);
            if (v != null) {
                v.moveTo(this.getX() + (i - 1) * 2.5, this.getY(), this.getZ() + 2.5);
                v.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(net.minecraft.world.item.Items.IRON_AXE));
                level.addFreshEntity(v);
                summonedMobs.add(v.getUUID());
            }
        }
    }

    private void spawnTemporaryLava(ServerLevel level) {
        clearTemporaryLava(level);
        if (arenaCenter == null) arenaCenter = this.blockPosition();
        for (int i = 0; i < 10; i++) {
            int dx = this.random.nextInt(13) - 6;
            int dz = this.random.nextInt(13) - 6;
            BlockPos lavaPos = arenaCenter.offset(dx, 0, dz);
            if (level.getBlockState(lavaPos).is(Blocks.DEEPSLATE_TILES)) {
                level.setBlock(lavaPos, Blocks.LAVA.defaultBlockState(), 3);
                temporaryLavaPos.add(lavaPos);
            }
        }
    }

    private void clearTemporaryLava(ServerLevel level) {
        for (BlockPos pos : temporaryLavaPos) {
            if (level.getBlockState(pos).is(Blocks.LAVA)) {
                level.setBlock(pos, Blocks.DEEPSLATE_TILES.defaultBlockState(), 3);
            }
        }
        temporaryLavaPos.clear();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // Invulnerável nos Rounds 1 e 2, e no Round 3 só toma dano quando está TONTO!
        if (getRound() < 3 || !isStunned()) {
            if (!this.level.isClientSide && source.getEntity() instanceof Player p) {
                p.displayClientMessage(new TextComponent("§5O Mágico está protegido por magia!"), true);
            }
            return false;
        }

        // Quando tonto, cada ciclo permite tirar até ~34 de dano (3 ciclos de tontura para matar os 100 HP)
        float cappedDamage = Math.min(amount, 34.0F);
        boolean damaged = super.hurt(source, cappedDamage);

        if (!this.level.isClientSide && damaged && this.isAlive()) {
            stunCyclesCompleted++;
            setStunned(false);
            if (this.getHealth() <= 2.0F || stunCyclesCompleted >= 3) {
                this.setHealth(0.0F);
                this.die(source);
            } else {
                // Volta para a fase de lava + mão gigante até o próximo atordoamento
                round3SubPhase = 2;
                phaseTimer = 0;
                if (this.level instanceof ServerLevel serverLevel) {
                    spawnTemporaryLava(serverLevel);
                    broadcastMessage(serverLevel, "§4[Mágico Gigante] §cAaargh! (" + stunCyclesCompleted + "/3 golpes críticos!)");
                }
            }
        }
        return damaged;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level.isClientSide && this.level instanceof ServerLevel serverLevel) {
            clearTemporaryLava(serverLevel);
            this.spawnAtLocation(ModItems.VARINHA_MAGICO.get());
            broadcastMessage(serverLevel, "§6§lO Mágico Supremo foi derrotado e dropou sua Varinha!");
        }
        this.bossEvent.removeAllPlayers();
        super.die(source);
    }

    private void broadcastMessage(ServerLevel level, String msg) {
        for (ServerPlayer p : level.getPlayers(p -> p.distanceToSqr(this) < 1600.0D)) {
            p.sendMessage(new TextComponent(msg), this.getUUID());
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.EVOKER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.EVOKER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.EVOKER_DEATH;
    }
}
