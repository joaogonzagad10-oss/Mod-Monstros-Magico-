package com.monstrosmagicos.mod.entity;

import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.custom.MagicoEntity;
import com.monstrosmagicos.mod.entity.custom.MonstroGeleiaEntity;
import com.monstrosmagicos.mod.entity.custom.MonstroLuzEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, MonstrosMagicosMod.MOD_ID);

    public static final RegistryObject<EntityType<MonstroLuzEntity>> MONSTRO_LUZ =
            ENTITY_TYPES.register("monstro_luz",
                    () -> EntityType.Builder.of(MonstroLuzEntity::new, MobCategory.MONSTER)
                            .sized(0.6F, 1.95F)
                            .build(new ResourceLocation(MonstrosMagicosMod.MOD_ID, "monstro_luz").toString()));

    public static final RegistryObject<EntityType<MonstroGeleiaEntity>> MONSTRO_GELEIA =
            ENTITY_TYPES.register("monstro_geleia",
                    () -> EntityType.Builder.of(MonstroGeleiaEntity::new, MobCategory.MONSTER)
                            .sized(1.4F, 1.4F)
                            .build(new ResourceLocation(MonstrosMagicosMod.MOD_ID, "monstro_geleia").toString()));

    public static final RegistryObject<EntityType<MagicoEntity>> MAGICO =
            ENTITY_TYPES.register("magico",
                    () -> EntityType.Builder.of(MagicoEntity::new, MobCategory.MONSTER)
                            .sized(0.8F, 2.2F)
                            .fireImmune()
                            .build(new ResourceLocation(MonstrosMagicosMod.MOD_ID, "magico").toString()));

    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}
