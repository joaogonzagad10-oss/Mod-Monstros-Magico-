package com.monstrosmagicos.mod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.custom.MonstroGeleiaEntity;
import net.minecraft.client.model.SlimeModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MonstroGeleiaRenderer extends MobRenderer<MonstroGeleiaEntity, SlimeModel<MonstroGeleiaEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MonstrosMagicosMod.MOD_ID, "textures/entity/monstro_geleia.png");

    public MonstroGeleiaRenderer(EntityRendererProvider.Context context) {
        super(context, new SlimeModel<>(context.bakeLayer(ModelLayers.SLIME)), 0.7F);
    }

    @Override
    protected void scale(MonstroGeleiaEntity entity, PoseStack poseStack, float partialTickTime) {
        poseStack.scale(2.4F, 2.4F, 2.4F);
    }

    @Override
    public ResourceLocation getTextureLocation(MonstroGeleiaEntity entity) {
        return TEXTURE;
    }
}
