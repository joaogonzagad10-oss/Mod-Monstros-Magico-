package com.monstrosmagicos.mod.entity.custom;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class MonstroLuzEntity extends Monster {
    // Armazena jogadores amaldiçoados pelo toque do Monstro de Luz (drena até 1 coração = 2.0F)
    private static final Map<UUID, Integer> CURSED_PLAYERS = new HashMap<>();

    public MonstroLuzEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 15;
        if (this.getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 36.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.29D)
                .add(Attributes.ATTACK_DAMAGE, 4.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.ARMOR, 3.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new BreakDoorGoal(this, (difficulty) -> true));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15D, false));
        this.goalSelector.addGoal(3, new SeekNonTorchLightGoal(this, 1.05D, 18));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.85D));
        this.goalSelector.addGoal(5, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level.isClientSide && this.level instanceof ServerLevel serverLevel) {
            if (this.tickCount % 5 == 0) {
                serverLevel.sendParticles(ParticleTypes.END_ROD,
                        this.getX(), this.getY() + 1.1D, this.getZ(),
                        2, 0.3, 0.5, 0.3, 0.01);
            }

            // Quebra portas próximas no caminho automaticamente
            if (this.tickCount % 15 == 0) {
                BlockPos pos = this.blockPosition();
                for (BlockPos check : BlockPos.betweenClosed(pos.offset(-1, 0, -1), pos.offset(1, 2, 1))) {
                    BlockState state = this.level.getBlockState(check);
                    if (state.getBlock() instanceof DoorBlock) {
                        this.level.destroyBlock(check, true, this);
                        this.playSound(SoundEvents.ZOMBIE_BREAK_WOODEN_DOOR, 1.0F, 1.0F);
                    }
                }
            }

            // Processa dreno de vida contínuo até 1 coração (2.0F HP)
            if (this.tickCount % 20 == 0 && !CURSED_PLAYERS.isEmpty()) {
                Iterator<Map.Entry<UUID, Integer>> it = CURSED_PLAYERS.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<UUID, Integer> entry = it.next();
                    Player target = serverLevel.getPlayerByUUID(entry.getKey());
                    if (target == null || !target.isAlive() || target.isCreative() || target.isSpectator()) {
                        it.remove();
                        continue;
                    }
                    if (target.getHealth() > 2.0F) {
                        float nextHealth = Math.max(2.0F, target.getHealth() - 2.0F);
                        target.hurt(DamageSource.MAGIC, 0.01F);
                        target.setHealth(nextHealth);
                        serverLevel.sendParticles(ParticleTypes.GLOW,
                                target.getX(), target.getY() + 1.0D, target.getZ(),
                                8, 0.3, 0.5, 0.3, 0.02);
                    }
                    if (target.getHealth() <= 2.0F || entry.getValue() <= 0) {
                        it.remove();
                    } else {
                        entry.setValue(entry.getValue() - 1);
                    }
                }
            }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hit = super.doHurtTarget(target);
        if (hit && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.GLOWING, 160, 0));
            if (target instanceof Player player && !player.isCreative()) {
                // Ativa o dreno até ficar com 1 coração (2.0F)
                CURSED_PLAYERS.put(player.getUUID(), 30);
            }
        }
        return hit;
    }

    public static boolean isNonTorchLight(BlockState state) {
        if (state.getLightEmission() <= 0) return false;
        if (state.is(Blocks.TORCH) || state.is(Blocks.WALL_TORCH)
                || state.is(Blocks.SOUL_TORCH) || state.is(Blocks.SOUL_WALL_TORCH)
                || state.is(Blocks.REDSTONE_TORCH) || state.is(Blocks.REDSTONE_WALL_TORCH)
                || state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
                || state.is(Blocks.LAVA)) {
            return false;
        }
        return true;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.HUSK_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.HUSK_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.HUSK_DEATH;
    }

    // Goal customizado: procura fontes de luz que não sejam tochas e vai até elas
    static class SeekNonTorchLightGoal extends Goal {
        private final MonstroLuzEntity mob;
        private final double speed;
        private final int searchRadius;
        private BlockPos targetLightPos;

        public SeekNonTorchLightGoal(MonstroLuzEntity mob, double speed, int searchRadius) {
            this.mob = mob;
            this.speed = speed;
            this.searchRadius = searchRadius;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.mob.getTarget() != null) return false;
            if (this.mob.tickCount % 25 != 0) return false;
            BlockPos origin = this.mob.blockPosition();
            BlockPos closest = null;
            double bestDist = Double.MAX_VALUE;

            for (BlockPos pos : BlockPos.betweenClosed(
                    origin.offset(-searchRadius, -4, -searchRadius),
                    origin.offset(searchRadius, 6, searchRadius))) {
                BlockState state = this.mob.level.getBlockState(pos);
                if (isNonTorchLight(state)) {
                    double dist = pos.distSqr(origin);
                    if (dist < bestDist) {
                        bestDist = dist;
                        closest = pos.immutable();
                    }
                }
            }
            this.targetLightPos = closest;
            return this.targetLightPos != null;
        }

        @Override
        public void start() {
            if (this.targetLightPos != null) {
                this.mob.getNavigation().moveTo(
                        this.targetLightPos.getX() + 0.5,
                        this.targetLightPos.getY(),
                        this.targetLightPos.getZ() + 0.5,
                        this.speed);
            }
        }

        @Override
        public boolean canContinueToUse() {
            return this.targetLightPos != null
                    && this.mob.getTarget() == null
                    && isNonTorchLight(this.mob.level.getBlockState(this.targetLightPos))
                    && this.targetLightPos.distSqr(this.mob.blockPosition()) > 3.0D;
        }
    }
}
