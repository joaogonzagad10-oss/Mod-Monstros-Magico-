package com.monstrosmagicos.mod.entity.custom;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

public class MonstroGeleiaEntity extends Monster {
    private UUID trappedPlayerId = null;
    private int hitsToEscape = 0;
    private int escapeCooldown = 0;

    public MonstroGeleiaEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 12;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.7D)
                .add(Attributes.FOLLOW_RANGE, 24.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1D, false));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level.isClientSide) return;

        if (escapeCooldown > 0) {
            escapeCooldown--;
        }

        if (trappedPlayerId != null && this.level instanceof ServerLevel serverLevel) {
            Player trapped = serverLevel.getPlayerByUUID(trappedPlayerId);
            if (trapped == null || !trapped.isAlive() || trapped.isCreative() || trapped.isSpectator()) {
                trappedPlayerId = null;
                hitsToEscape = 0;
                return;
            }

            // Mantém o jogador preso dentro do corpo da geleia
            trapped.teleportTo(this.getX(), this.getY() + 0.15D, this.getZ());
            trapped.setDeltaMovement(Vec3.ZERO);
            trapped.fallDistance = 0.0F;
            trapped.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false));
            trapped.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 25, 0, false, false));

            if (this.tickCount % 5 == 0) {
                serverLevel.sendParticles(ParticleTypes.ITEM_SLIME,
                        this.getX(), this.getY() + 0.8D, this.getZ(),
                        12, 0.5, 0.5, 0.5, 0.05);
            }

            // Dano de sufocamento dentro da geleia a cada 1 segundo
            if (this.tickCount % 20 == 0) {
                trapped.hurt(DamageSource.IN_WALL, 3.0F);
                trapped.displayClientMessage(
                        new TextComponent("§aVocê está preso na geleia! Bata nela mais §e" + hitsToEscape + "x §apara sair!"),
                        true);
            }
        } else if (escapeCooldown == 0 && this.tickCount % 4 == 0) {
            // Se um jogador ficar perto demais (< 1.45 blocos), é engolido para dentro da geleia
            Player nearest = this.level.getNearestPlayer(this, 1.45D);
            if (nearest != null && !nearest.isCreative() && !nearest.isSpectator()) {
                this.trappedPlayerId = nearest.getUUID();
                this.hitsToEscape = 5; // Precisa bater 5 vezes para ser jogado para fora
                this.playSound(SoundEvents.SLIME_ATTACK, 1.3F, 0.7F);
                nearest.displayClientMessage(
                        new TextComponent("§2O Monstro Geleia te engoliu! Bata nele 5 vezes para escapar!"),
                        true);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (!this.level.isClientSide && result && trappedPlayerId != null) {
            Entity attacker = source.getEntity();
            if (attacker instanceof Player player && player.getUUID().equals(trappedPlayerId)) {
                hitsToEscape--;
                this.playSound(SoundEvents.SLIME_SQUISH, 1.2F, 1.1F);
                if (hitsToEscape <= 0) {
                    // Joga o jogador para fora com impulso
                    Vec3 look = player.getLookAngle();
                    Vec3 launch = new Vec3(-look.x * 1.4D, 0.65D, -look.z * 1.4D);
                    if (launch.horizontalDistanceSqr() < 0.1D) {
                        launch = new Vec3(1.2D, 0.65D, 0.0D);
                    }
                    player.setDeltaMovement(launch);
                    player.hurtMarked = true;
                    player.removeEffect(MobEffects.BLINDNESS);
                    player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
                    player.displayClientMessage(new TextComponent("§aVocê escapou da geleia!"), true);

                    this.trappedPlayerId = null;
                    this.escapeCooldown = 60; // 3 segundos de imunidade antes de engolir de novo
                    this.playSound(SoundEvents.SLIME_JUMP, 1.5F, 0.6F);
                } else {
                    player.displayClientMessage(
                            new TextComponent("§aFaltam §e" + hitsToEscape + " §agolpes para sair!"),
                            true);
                }
            }
        }
        return result;
    }

    @Override
    public void die(DamageSource source) {
        if (!this.level.isClientSide && trappedPlayerId != null && this.level instanceof ServerLevel serverLevel) {
            Player trapped = serverLevel.getPlayerByUUID(trappedPlayerId);
            if (trapped != null) {
                trapped.removeEffect(MobEffects.BLINDNESS);
                trapped.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
            }
            trappedPlayerId = null;
        }
        super.die(source);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SLIME_SQUISH;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SLIME_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH;
    }
}
