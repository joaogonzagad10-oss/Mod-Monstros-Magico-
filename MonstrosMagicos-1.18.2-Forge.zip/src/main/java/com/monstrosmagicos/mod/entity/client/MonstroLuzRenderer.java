package com.monstrosmagicos.mod.entity.client;

import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.custom.MonstroLuzEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class MonstroLuzRenderer extends HumanoidMobRenderer<MonstroLuzEntity, HumanoidModel<MonstroLuzEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MonstrosMagicosMod.MOD_ID, "textures/entity/monstro_luz.png");

    public MonstroLuzRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.HUSK)), 0.5F);
    }

    @Override
    protected int getBlockLightLevel(MonstroLuzEntity entity, BlockPos pos) {
        return 15; // Brilha intensamente no escuro como uma múmia brilhante!
    }

    @Override
    public ResourceLocation getTextureLocation(MonstroLuzEntity entity) {
        return TEXTURE;
    }
}
