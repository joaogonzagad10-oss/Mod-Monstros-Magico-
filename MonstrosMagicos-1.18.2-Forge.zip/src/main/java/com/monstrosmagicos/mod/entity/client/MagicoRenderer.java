package com.monstrosmagicos.mod.entity.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.custom.MagicoEntity;
import net.minecraft.client.model.IllagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class MagicoRenderer extends MobRenderer<MagicoEntity, IllagerModel<MagicoEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(MonstrosMagicosMod.MOD_ID, "textures/entity/magico.png");

    public MagicoRenderer(EntityRendererProvider.Context context) {
        super(context, new IllagerModel<>(context.bakeLayer(ModelLayers.EVOKER)), 0.6F);
        this.addLayer(new ItemInHandLayer<>(this));
    }

    @Override
    protected void scale(MagicoEntity entity, PoseStack poseStack, float partialTickTime) {
        if (entity.isGiantMode()) {
            poseStack.scale(2.6F, 2.6F, 2.6F); // Fica gigante no Round 3!
        } else {
            poseStack.scale(1.1F, 1.1F, 1.1F);
        }
    }

    @Override
    public ResourceLocation getTextureLocation(MagicoEntity entity) {
        return TEXTURE;
    }
}
