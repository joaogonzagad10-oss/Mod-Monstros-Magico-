package com.monstrosmagicos.mod.entity.client;

import com.monstrosmagicos.mod.MonstrosMagicosMod;
import com.monstrosmagicos.mod.entity.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MonstrosMagicosMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MONSTRO_LUZ.get(), MonstroLuzRenderer::new);
        event.registerEntityRenderer(ModEntities.MONSTRO_GELEIA.get(), MonstroGeleiaRenderer::new);
        event.registerEntityRenderer(ModEntities.MAGICO.get(), MagicoRenderer::new);
    }
}
